#!/usr/bin/env python3
"""
SO100 Robot Driver Demo
Simple Pick and Place Test
Created by Sandor Burian with the help of Google Gemini Pro.
This script demonstrates a simple pick and place operation using the SO100 robotic arm and its gripper with cartesian coordinate system.
"""

import sys
import os
import time

from so100_core import SO100Robot
from utils import get_robot_configuration


def simple_pick_and_place():
    # Get robot configuration using the utility function
    config = get_robot_configuration()
    PORT = config['port']
    CALIB_FILE = config['calib_file'] 
    URDF_PATH = config['urdf_path']
      
    robot = SO100Robot(port=PORT, config_dir="config")

    print("--- PICK & PLACE DEMO ---")
    
    
    GRIPPER_OPEN = robot.get_gripper_open_position() 
    GRIPPER_CLOSE = robot.get_gripper_close_position()
    
    # Test coordinates
    PICK_POS = [0.25, 0.05, 0.03]  # right, forward down
    PLACE_POS = [0.25, -0.05, 0.03] # left, forward, down
    PLACE_POS2 = [-0.20, 0.05, 0.1] # left, backward, down
    SAFE_Z = 0.15 # safety high
    # --------------------
    
    def move_to(driver, x, y, z):
        print(f"Move to: {x}, {y}, {z}")
        target_pos = [x, y, z]
        seed_state = [0] * len(driver.chain.links) 
        target_joints = driver.chain.inverse_kinematics(target_position=target_pos, initial_position=seed_state)
            
        # Printing the calculated angles (in Radians)
        # Note: target_joints[0] is usually the Base (which is fixed at 0), so motors start from 1
        print("Calculated angles (Radians):")
        for i in range(1, len(target_joints)):
            # Handling ikpy index offset
            if i <= 6:
                print(f"  J{i}: {target_joints[i]:.2f}")

            # --- MOVEMENT ---
            move_time = 2000 # 2 seconds (safe speed)
            
            # The IKPy array also contains the "Base link" at index 0.
            # Our driver's set_target_angle(0) command corresponds to motor 1 (J1).
            # So: driver Motor 0 -> IKPy Joint 1
            
            print("Moving...")
            for motor_idx in range(6): # 0..5 (Motor 1..6)
                # IKPy Joint index: motor_idx + 1
                ik_angle = target_joints[motor_idx + 1]
                
                # Sending to the driver (which will add the calibration offset)
                driver.set_target_angle(motor_idx, ik_angle, move_time_ms=move_time)
                time.sleep(0.05)

    print("\n\n==== Pick and place Simulation ====\n\nStarting...")
    print("Open positions:", GRIPPER_OPEN)
    print("Close position:", GRIPPER_CLOSE)
    print("Waking up motors...")
    robot.torque_enable(True)

    # 1. Open (gyorsabb timing)
    robot.gripper_open()
    robot.move_to_cartesian(PICK_POS[0], PICK_POS[1], SAFE_Z, time_ms=800)  # Gyorsabb mozgás
    
    # 2. Close (gyors leeresztés)
    robot.move_to_cartesian(PICK_POS[0], PICK_POS[1], PICK_POS[2], time_ms=500)  # Gyors leeresztés
    robot.gripper_close()
    robot.move_to_cartesian(PICK_POS[0], PICK_POS[1], SAFE_Z, time_ms=800)  # Gyors felemeés
    
    robot.move_to_cartesian(PLACE_POS[0], PLACE_POS[1], PLACE_POS[2], time_ms=1000)  # Közepes sebesség
    # 3. Open again
    robot.gripper_open()
    robot.move_to_cartesian(PLACE_POS[0], PLACE_POS[1], SAFE_Z, time_ms=600)  # Gyors távozás
    
    robot.gripper_close()

    print("Test done!")
    finish = input("Press x to release the arm!")
    if finish == "x":
        print("Exiting. Releasing motors...")
        robot.torque_enable(False)

if __name__ == "__main__":
    simple_pick_and_place()